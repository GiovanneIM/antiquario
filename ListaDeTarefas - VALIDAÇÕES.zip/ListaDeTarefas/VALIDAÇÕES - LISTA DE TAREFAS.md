VALIDAÇÕES - LISTA DE TAREFAS



GET ('/:id') - Visualizar uma tarefa específica

* *Verificar se o id informado é um número e se existe na lista;*



POST - Criação de tarefas

* *Verificar se o usuário não deixou o corpo da requisição vazio ou incompleto;*
* *Validar o conteúdo da descrição (vazio, insuficiente ou não string);*
* *Validar o conteúdo do status (vazio, insuficiente ou não string);*
* *Verificar se o status tem um valor válido ("Cancelado", "Pendente" ou "Concluída")*





PUT - Atualizar uma tarefa por completo

* *Verificar se o id informado é um número e se existe na lista;*
* *Verificar se o usuário não deixou o corpo da requisição vazio ou incompleto;*
* *Validar o conteúdo da descrição (vazio, insuficiente ou não string);*
* *Validar o conteúdo do status (vazio, insuficiente ou não string);*
* *Verificar se o status tem um valor válido ("Cancelado", "Pendente" ou "Concluída")*





PATCH - Atualizar uma tarefa

* *Verificar se o id informado é um número e se existe na lista;*
* *Verificar se o usuário não deixou o corpo da requisição vazio ou incompleto;*
* *Validar o conteúdo da atualização (vazio, insuficiente ou não string);*
* *Se o atributo modificado for status -> Verificar se tem um valor válido ("Cancelado", "Pendente" ou "Concluída")*





DELETE - Deletar uma tarefa

* *Verificar se o id informado existe na lista;*
