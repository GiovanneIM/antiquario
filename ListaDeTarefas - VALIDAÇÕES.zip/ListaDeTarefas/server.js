const express = require('express');
const app = express();
const port = 3000;



// MIDDLEWARES

// Logger
const logger = require('./middlewares/logger.js');
app.use(logger);

// Autenticação
const autenticacao = require('./middlewares/autenticacao.js');
app.use(autenticacao);

// Recebimento de JSON
app.use(express.json());



// ROTAS
const rotasTarefas = require('./rotas/rotasTarefas.js');
app.use('/', rotasTarefas);



// INICIANDO O SERVIDOR
app.listen(port, () => {
    console.log(`Server rodando em: http://localhost:${port}`);
});