const express = require('express');
const router = express.Router();

const fs = require('fs');
const { isNumberObject } = require('util/types');

const listaDeTarefas = './dados/tarefas.json';

const statusValidos = ["cancelada", "pendente", "concluida"];

// VISUALIZAR a lista de tarefas
router.get('/', (req, res) => {
    // Lendo a lista de tarefas1
    fs.readFile(listaDeTarefas, 'utf8', (err, data) => {
        // Erro ao ler arquivo
        if (err) {
            console.error('Erro: ' + err);
            res.status(404).res('Erro: ' + err);
        }

        // Convertendo a lista para JSON
        let tarefas;
        try {
            tarefas = JSON.parse(data);
        } catch (error) {
            // Erro ao converter a lista
            console.error('Erro: ' + err);
            res.status(404).res('Erro: ' + err);
        }

        // Enviando resposta
        res.status(200).send(JSON.stringify(tarefas, 0, 4))
    })
});


// VISUALIZAR uma tarefa específica
router.get('/:id', (req, res) => {
    let id;
    try {
        id = parseInt(req.params.id);
    } catch (error) {
        console.error('Erro: ' + error);
        res.status(400).send('ID inválido')
    }


    // Lendo a lista de tarefas
    fs.readFile(listaDeTarefas, 'utf8', (err, data) => {
        // Erro ao ler arquivo
        if (err) {
            console.error('Erro: ' + err);
            res.status(404).res('Erro: ' + err);
        }

        // Convertendo a lista para JSON
        let tarefas;
        try {
            tarefas = JSON.parse(data);
        } catch (error) {
            // Erro ao converter a lista
            console.error('Erro: ' + err);
            res.status(404).res('Erro: ' + err);
        }

        // Procurando pela tarefa com o id passado
        const tarefa = tarefas.find(function (tarefa) {
            return tarefa.id === id;
        });

        // Caso não exista uma tarefa com o ID passado
        if (!tarefa) {
            console.log(`Tarefa com o id '${id}' não encontrada.\n`);
            res.status(404).send(`Tarefa com o id '${id}' não encontrada.\n`);
        }
        // Se a tarefa foi encontrada
        else {
            console.log(JSON.stringify(tarefa, 0, 4));
            res.status(201).send(JSON.stringify(tarefa, 0, 4));
        }
    })
});


// CRIAR uma nova tarefa
router.post('/', (req, res) => {
    // Obtendo as informações da tarefa
    let descricao;
    let status;

    try {
        descricao = req.body.descricao.trim();
        status = req.body.status.trim();

        console.log(typeof (status));

        if (typeof (descricao) != 'string' || typeof (status) != 'string') {
            console.error('Erro: Descrição ou status recebidos não eram do tipo String ou estavam vazios.');
            res.status(400).send('Erro: Descrição ou status não eram do tipo String ou estavam vazios.')
            return;
        }

        if (descricao.length < 3) {
            console.error('Erro: A descrição deve ter um mínimo de 3 caracteres');
            res.status(400).send('Erro: A descrição deve ter um mínimo de 3 caracteres')
            return;
        }

        const i = statusValidos.indexOf(req.body.status.toLowerCase);
        if (i == -1) {
            console.error('Erro: Status inválido.');
            res.status(400).send('Erro: Escolha um valor válido para o status da tarefa.\n' + statusValidos)
            return;
        }
        else {
            tarefa.status = statusValidos[i];
        }
    } catch (error) {
        console.error('Erro: ' + error);
        res.status(400).send('As informações passadas não são válidas. (ex: Vazias, ou não eram strings)')
        return;
    }


    // Lendo a lista de tarefas
    fs.readFile(listaDeTarefas, 'utf8', (err, data) => {
        // Erro ao ler arquivo
        if (err) {
            console.error('Erro: ' + err);
            res.status(404).res('Erro: ' + err);
        }

        // Convertendo a lista para JSON
        let tarefas;
        try {
            tarefas = JSON.parse(data);
        } catch (error) {
            // Erro ao converter a lista
            console.error('Erro: ' + err);
            res.status(404).res('Erro: ' + err);
        }

        // Criando o objeto da nova tarefa
        const novaTarefa = {
            "id": tarefas[tarefas.length - 1].id + 1,
            "descricao": descricao,
            "status": status
        }

        // Adicionando a tarefa 
        tarefas.push(novaTarefa)

        // Salvando a lista
        fs.writeFile(listaDeTarefas, JSON.stringify(tarefas, 0, 4), (err) => {
            if (err) {
                console.error('Erro: ' + err);
                res.status(404).send('Erro: ' + err)
            }

            console.log(`Nova terefa registrada: \n   ID: ${novaTarefa.id} \n   Descrição: '${novaTarefa.descricao}' \n   Status '${novaTarefa.status}'\n`);
            res.status(201).send(`Nova terefa registrada: \n   ID: ${novaTarefa.id} \n   Descrição: '${novaTarefa.descricao}' \n   Status '${novaTarefa.status}'\n`);
        });
    });
});


// ATUALIZAR uma tarefa POR COMPLETA
router.put('/:id', (req, res) => {
    // Obtendo as informações da tarefa
    let id;
    try {
        id = parseInt(req.params.id);
    } catch (error) {
        console.error('Erro: ' + error);
        res.status(400).send('ID inválido')
    }

    let descricao;
    let status;

    try {
        descricao = req.body.descricao.trim();
        status = req.body.status.trim();

        if (typeof (descricao) != 'string' || typeof (status) != 'string') {
            console.error('Erro: Descrição ou status recebidos não eram do tipo String ou estavam vazios.');
            res.status(400).send('Erro: Descrição ou status não eram do tipo String ou estavam vazios.')
            return;
        }

        if (descricao.length < 3) {
            console.error('Erro: A descrição deve ter um mínimo de 3 caracteres');
            res.status(400).send('Erro: A descrição deve ter um mínimo de 3 caracteres')
            return;
        }

        const i = statusValidos.indexOf(req.body.status.toLowerCase);
        if (i == -1) {
            console.error('Erro: Status inválido.');
            res.status(400).send('Erro: Escolha um valor válido para o status da tarefa.\n' + statusValidos)
            return;
        }
        else {
            tarefa.status = statusValidos[i];
        }
    } catch (error) {
        console.error('Erro: ' + error);
        res.status(400).send('As informações passadas não são válidas. (ex: Vazias, ou não eram strings)')
        return;
    }

    // Lendo a lista de tarefas
    fs.readFile(listaDeTarefas, 'utf8', (err, data) => {
        // Erro ao ler arquivo
        if (err) {
            console.error('Erro: ' + err);
            res.status(404).res('Erro: ' + err);
        }

        // Convertendo a lista para JSON
        let tarefas;
        try {
            tarefas = JSON.parse(data);
        } catch (error) {
            // Erro ao converter a lista
            console.error('Erro: ' + err);
            res.status(404).res('Erro: ' + err);
        }

        // Procurando a tarefa com o id passado e atualizando suas informações
        const tarefa = tarefas.find(function (tarefa) {
            if (tarefa.id === id) {
                tarefa.descricao = descricao;
                tarefa.status = status;
                return true
            }
            else { return false }
        })

        // Caso não exista uma tarefa com o ID passado
        if (!tarefa) {
            console.log(`Tarefa com o id '${id}' não encontrada.\n`);
            res.status(404).send(`Tarefa com o id '${id}' não encontrada.\n`);
        }
        // Se a tarefa foi encontrada
        else {
            // Salvando a lista
            fs.writeFile(listaDeTarefas, JSON.stringify(tarefas, 0, 4), (err) => {
                if (err) {
                    console.error('Erro: ' + err);
                    res.status(404).send('Erro: ' + err)
                }

                console.log(`Tarefa atualizada: \n   ID: ${tarefa.id} \n   Descrição: '${tarefa.descricao}' \n   Status '${tarefa.status}'\n`);
                res.status(200).send(`Tarefa atualizada: \n   ID: ${tarefa.id} \n   Descrição: '${tarefa.descricao}' \n   Status '${tarefa.status}'\n`);
            });
        }
    });
});

// ATUALIZAR uma tarefa PARCIALMENTE
router.patch('/:id', (req, res) => {
    // Obtendo as informações da tarefa
    let id;
    try {
        id = parseInt(req.params.id);
    } catch (error) {
        console.error('Erro: ' + error);
        res.status(400).send('ID inválido')
    }

    // Lendo a lista de tarefas
    fs.readFile(listaDeTarefas, 'utf8', (err, data) => {
        // Erro ao ler arquivo
        if (err) {
            console.error('Erro: ' + err);
            res.status(404).res('Erro: ' + err);
        }

        // Convertendo a lista para JSON
        let tarefas;
        try {
            tarefas = JSON.parse(data);
        } catch (error) {
            // Erro ao converter a lista
            console.error('Erro: ' + err);
            res.status(404).res('Erro: ' + err);
        }

        // Procurando a tarefa com o id passado e atualizando suas informações
        const tarefa = tarefas.find(function (tarefa) {
            if (tarefa.id === id) {
                if (req.body.descricao) {
                    const novaDescricao = req.body.descricao
                    if (typeof (novaDescricao) != 'string') {
                        console.error('Erro: Descrição ou status recebidos não eram do tipo String ou estavam vazios.');
                        res.status(400).send('Erro: Descrição ou status não eram do tipo String ou estavam vazios.')
                        return;
                    }

                    if (descricao.length < 3) {
                        console.error('Erro: A descrição deve ter um mínimo de 3 caracteres');
                        res.status(400).send('Erro: A descrição deve ter um mínimo de 3 caracteres')
                        return;
                    }

                    tarefa.descricao = req.body.descricao
                }

                if (req.body.status) {
                    const i = statusValidos.indexOf(req.body.status.toLowerCase);
                    if (i != -1) {
                        tarefa.status = statusValidos[i];
                    }
                }

                return true
            }
            else { return false }
        })

        // Caso não exista uma tarefa com o ID passado
        if (!tarefa) {
            console.log(`Tarefa com o id '${id}' não encontrada.\n`);
            res.status(404).send(`Tarefa com o id '${id}' não encontrada.\n`);
        }
        // Se a tarefa foi encontrada
        else {
            // Salvando a lista
            fs.writeFile(listaDeTarefas, JSON.stringify(tarefas, 0, 4), (err) => {
                if (err) {
                    console.error('Erro: ' + err);
                    res.status(404).send('Erro: ' + err)
                }

                console.log(`Tarefa atualizada: \n   ID: ${tarefa.id} \n   Descrição: '${tarefa.descricao}' \n   Status '${tarefa.status}'\n`);
                res.status(200).send(`Tarefa atualizada: \n   ID: ${tarefa.id} \n   Descrição: '${tarefa.descricao}' \n   Status '${tarefa.status}'\n`);
            });
        }
    });
});


// DELETAR uma tarefa
router.delete('/:id', (req, res) => {
    let id;
    try {
        id = parseInt(req.params.id);
    } catch (error) {
        console.error('Erro: ' + error);
        res.status(400).send('ID inválido')
    }

    // Lendo a lista de tarefas
    fs.readFile(listaDeTarefas, 'utf8', (err, data) => {
        // Erro ao ler arquivo
        if (err) {
            console.error('Erro: ' + err);
            res.status(404).res('Erro: ' + err);
        }

        // Convertendo a lista para JSON
        let tarefas;
        try {
            tarefas = JSON.parse(data);
        } catch (error) {
            // Erro ao converter a lista
            console.error('Erro: ' + err);
            res.status(404).res('Erro: ' + err);
        }

        // Procurando a tarefa com o id passado
        const tarefa = tarefas.find(function (tarefa) {
            return tarefa.id === id;
        });

        // Caso não exista uma tarefa com o ID passado
        if (!tarefa) {
            console.error(`Tarefa com o id '${id}' não encontrada.\n`);
            res.status(404).send(`Tarefa com o id '${id}' não encontrada.\n`);
        }
        // Se a tarefa foi encontrada
        else {
            // Encontrando o index da tarefa no vetor tarefas
            const indexTarefa = tarefas.indexOf(tarefa)

            // Removendo a tarefa do vetor
            tarefas.splice(indexTarefa, 1)

            // Salvando a lista
            fs.writeFile(listaDeTarefas, JSON.stringify(tarefas, 0, 4), (err) => {
                if (err) {
                    console.error('Erro: ' + err);
                    res.status(404).send('Erro: ' + err)
                }

                console.log(`Tarefa excluída: \n   ID: ${tarefa.id} \n   Descrição: '${tarefa.descricao}' \n   Status '${tarefa.status}'\n`);
                res.status(200).send(`Tarefa excluída: \n   ID: ${tarefa.id} \n   Descrição: '${tarefa.descricao}' \n   Status '${tarefa.status}'\n`);
            });
        }
    });
});





//OPTIONS
router.options('/', (req, res) => {
    res.header('Allow', 'GET, POST, OPTIONS');
    res.status(204).send();
});

router.options('/:id', (req, res) => {
    res.header('Allow', 'GET, PUT, PATCH, DELETE, OPTIONS');
    res.status(204).send();
});



module.exports = router;